from shop.payment.bank_transfer_payment_strategy import BankTransferPaymentStrategy
from shop.payment.card_payment_strategy import CardPaymentStrategy
from shop.payment.cash_on_delivery_payment_strategy import CashOnDeliveryPaymentStrategy
from shop.payment.payment_strategy import PaymentStrategy
from shop.payment.paypal_payment_strategy import PayPalPaymentStrategy


class PaymentStrategyFactory:
    @staticmethod
    def create(payment_type: str) -> PaymentStrategy:
        normalized_type = payment_type.lower()

        if normalized_type == "card":
            return CardPaymentStrategy()
        if normalized_type == "paypal":
            return PayPalPaymentStrategy()
        if normalized_type == "cash":
            return CashOnDeliveryPaymentStrategy()
        if normalized_type == "bank-transfer":
            return BankTransferPaymentStrategy()

        raise ValueError(f"Nepoznat način plaćanja: {payment_type}")
