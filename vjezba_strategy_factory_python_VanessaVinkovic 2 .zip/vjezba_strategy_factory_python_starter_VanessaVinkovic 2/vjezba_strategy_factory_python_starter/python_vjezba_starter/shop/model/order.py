from dataclasses import dataclass, field


@dataclass
class Order:
    id: str
    customer_email: str
    total_amount: float
    status: str = field(default="NEW")
