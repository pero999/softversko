from shop.model.order import Order
from shop.payment.payment_result import PaymentResult
from shop.payment.payment_strategy import PaymentStrategy


class PayPalPaymentStrategy(PaymentStrategy):
    def execute(self, order: Order) -> PaymentResult:
        final_amount = order.total_amount + order.total_amount * 0.03
        return PaymentResult(
            final_amount=final_amount,
            payment_description="Plaćanje putem PayPal-a",
            status="PAID",
        )