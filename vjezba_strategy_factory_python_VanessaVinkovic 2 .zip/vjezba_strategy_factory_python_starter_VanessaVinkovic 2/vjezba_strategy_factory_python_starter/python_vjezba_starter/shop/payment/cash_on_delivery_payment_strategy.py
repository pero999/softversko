from shop.model.order import Order
from shop.payment.payment_result import PaymentResult
from shop.payment.payment_strategy import PaymentStrategy


class CashOnDeliveryPaymentStrategy(PaymentStrategy):
    def execute(self, order: Order) -> PaymentResult:
        return PaymentResult(
            final_amount=order.total_amount,
            payment_description="Plaćanje pouzećem",
            status="PENDING_PAYMENT",
        )