from dataclasses import dataclass


@dataclass
class PaymentResult:
    final_amount: float
    payment_description: str
    status: str