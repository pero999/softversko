from abc import ABC, abstractmethod

from shop.model.order import Order
from shop.payment.payment_result import PaymentResult


class PaymentStrategy(ABC):
    @abstractmethod
    def execute(self, order: Order) -> PaymentResult:
        pass