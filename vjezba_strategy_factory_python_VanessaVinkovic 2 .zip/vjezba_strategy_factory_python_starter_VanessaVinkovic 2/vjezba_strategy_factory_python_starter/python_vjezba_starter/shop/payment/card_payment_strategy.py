from shop.model.order import Order
from shop.payment.payment_result import PaymentResult
from shop.payment.payment_strategy import PaymentStrategy


class CardPaymentStrategy(PaymentStrategy):
    def execute(self, order: Order) -> PaymentResult:
        final_amount = order.total_amount + order.total_amount * 0.02
        return PaymentResult(
            final_amount=final_amount,
            payment_description="Plaćanje karticom",
            status="PAID",
        )