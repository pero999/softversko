from shop.model.order import Order
from shop.payment.payment_result import PaymentResult
from shop.payment.payment_strategy import PaymentStrategy


class BankTransferPaymentStrategy(PaymentStrategy):
    def execute(self, order: Order) -> PaymentResult:
        return PaymentResult(
            final_amount=order.total_amount,
            payment_description="Plaćanje bankovnom transakcijom",
            status="WAITING_FOR_TRANSFER",
        )