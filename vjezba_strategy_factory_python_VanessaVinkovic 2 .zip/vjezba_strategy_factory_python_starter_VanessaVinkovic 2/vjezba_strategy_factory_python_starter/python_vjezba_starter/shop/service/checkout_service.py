from shop.model.order import Order
from shop.payment.payment_strategy import PaymentStrategy


class CheckoutService:
    def checkout(self, order: Order, payment_strategy: PaymentStrategy, payment_type: str) -> None:
        if order is None:
            raise ValueError("Narudžba ne smije biti None.")

        if order.total_amount <= 0:
            raise ValueError("Iznos narudžbe mora biti veci od nule.")

        payment_result = payment_strategy.execute(order)
        order.status = payment_result.status

        print("=== CHECKOUT ===")
        print(f"Narudžba: {order.id}")
        print(f"Kupac: {order.customer_email}")
        print(f"Način plaćanja: {payment_result.payment_description}")
        print(f"Konačni iznos: {payment_result.final_amount}")
        print(f"Status: {order.status}")

        self.send_confirmation(order)
        self.save_audit_log(order, payment_type, payment_result.final_amount)

    def send_confirmation(self, order: Order) -> None:
        print(f"Potvrda poslana na: {order.customer_email}")

    def save_audit_log(self, order: Order, payment_type: str, final_amount: float) -> None:
        print(
            "LOG -> "
            f"order={order.id}, "
            f"payment_type={payment_type}, "
            f"amount={final_amount}, "
            f"status={order.status}"
        )
