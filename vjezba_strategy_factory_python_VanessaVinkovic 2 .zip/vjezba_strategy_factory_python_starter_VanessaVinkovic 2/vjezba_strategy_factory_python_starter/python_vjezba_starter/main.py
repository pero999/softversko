from shop.model.order import Order
from shop.factory.payment_strategy_factory import PaymentStrategyFactory
from shop.service.checkout_service import CheckoutService


def main() -> None:
    checkout_service = CheckoutService()

    order1 = Order("ORD-1001", "ana@example.com", 120.00)
    payment_strategy1 = PaymentStrategyFactory.create("card")
    checkout_service.checkout(order1, payment_strategy1, "card")

    print()

    order2 = Order("ORD-1002", "ivan@example.com", 80.00)
    payment_strategy2 = PaymentStrategyFactory.create("paypal")
    checkout_service.checkout(order2, payment_strategy2, "paypal")

    print()

    order3 = Order("ORD-1003", "marko@example.com", 55.00)
    payment_strategy3 = PaymentStrategyFactory.create("cash")
    checkout_service.checkout(order3, payment_strategy3, "cash")

    print()

    order4 = Order("ORD-1004", "petra@example.com", 100.00)
    payment_strategy4 = PaymentStrategyFactory.create("bank-transfer")
    checkout_service.checkout(order4, payment_strategy4, "bank-transfer")


if __name__ == "__main__":
    main()