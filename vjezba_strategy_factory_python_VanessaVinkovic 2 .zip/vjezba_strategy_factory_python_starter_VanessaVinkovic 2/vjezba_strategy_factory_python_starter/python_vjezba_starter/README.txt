Početni projekt za vježbu iz oblikovnih obrazaca.

Pokretanje:
python main.py

Cilj vježbe:
- refaktorirati CheckoutService primjenom Strategy obrasca
- uvesti Factory za stvaranje strategija
- dodati novi način plaćanja bez izmjene osnovne logike naplate


U ovom projektu primijenjeni su sljedeći obrasci dizajna:

Strategy pattern – za odvajanje različitih načina plaćanja u zasebne klase.
Factory pattern – za centralizirano stvaranje odgovarajuće strategije plaćanja na temelju ulaznog tipa.
Implementirane klase

U sustav su uvedene sljedeće klase:

Payment strategije:
PaymentStrategy (apstraktna klasa / sučelje)
CardPaymentStrategy
PayPalPaymentStrategy
CashOnDeliveryPaymentStrategy
BankTransferPaymentStrategy

Pomoćne klase:
Factory:
PaymentStrategyFactory – stvara odgovarajuću strategiju na temelju string ulaza (npr. "card", "paypal", "cash", "bank-transfer")
Servis:
CheckoutService – sada koristi samo apstrakciju PaymentStrategy i više ne sadrži logiku grananja za plaćanje